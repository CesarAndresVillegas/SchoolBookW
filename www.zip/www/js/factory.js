angular.module('starter')
    .factory('SharedService', function() {
        var SharedService = {
            userData: {},
            selectedType: "",
            backScreen: "",
            selectedMessage: {},
            selectedHost: [{id:1, host: "http://simple-it.co/apis/schoolbook/v1.0/"}]
        };
        return SharedService;
    });
